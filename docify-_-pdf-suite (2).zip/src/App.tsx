/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import AuthModal from './components/AuthModal';
import ProfileModal from './components/ProfileModal';
import TcModal from './components/TcModal';
import Logo, { LogoIcon } from './components/Logo';
import CompressTool from './components/Tools/CompressTool';
import MergeTool from './components/Tools/MergeTool';
import SplitTool from './components/Tools/SplitTool';
import RemoveTool from './components/Tools/RemoveTool';
import RotateTool from './components/Tools/RotateTool';
import WatermarkTool from './components/Tools/WatermarkTool';
import Pdf2ImgTool from './components/Tools/Pdf2ImgTool';
import ContactPage from './components/Pages/ContactPage';
import PrivacyPage from './components/Pages/PrivacyPage';
import TermsPage from './components/Pages/TermsPage';
import HistoryPage from './components/Pages/HistoryPage';
import { Tool, HistoryItem, User, HistoryFile } from './types';
import { auth } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { Minimize2, Combine, Scissors, Trash2, RotateCw, Stamp, Image as ImageIcon, ArrowRight, ShieldCheck, Zap, Heart, CheckCircle2 } from 'lucide-react';

const TOOLS: Tool[] = [
  { id: 'compress', name: 'Compress PDF', icon: 'compress', color: '#7c6af0', desc: 'Optimize images and streams to reduce file size with balanced levels.' },
  { id: 'merge', name: 'Merge PDFs', icon: 'merge', color: '#f06292', desc: 'Combine multiple documents in any custom arrangement into a single file.' },
  { id: 'split', name: 'Split PDF', icon: 'split', color: '#43e97b', desc: 'Disassemble document pages into individual single-page PDF files.' },
  { id: 'remove', name: 'Remove Pages', icon: 'remove', color: '#ffd740', desc: 'Visually select and strike out unnecessary pages from a loaded file.' },
  { id: 'rotate', name: 'Rotate Pages', icon: 'rotate', color: '#00c6ff', desc: 'Rotate specific boundaries or rotate entire sheets at 90-degree steps.' },
  { id: 'watermark', name: 'Add Watermark', icon: 'watermark', color: '#a78bfa', desc: 'Stamp editable, semi-transparent text watermarks centered onto your sheets.' },
  { id: 'pdf2img', name: 'PDF to Images', icon: 'img', color: '#fd746c', desc: 'Convert and extract pages losslessly into high-resolution PNG image grids.' },
];

// Helper to serialize history to local storage with base64 encoded Uint8Arrays
function serializeHistory(items: HistoryItem[]): string {
  const serialized = items.map((item) => {
    const files = item.files?.map((file) => {
      if (file.bytes) {
        let binary = '';
        const len = file.bytes.byteLength;
        for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(file.bytes[i]);
        }
        const base64 = window.btoa(binary);
        return {
          name: file.name,
          base64: base64,
        };
      }
      return {
        name: file.name,
        dataUrl: file.dataUrl,
      };
    });
    return {
      id: item.id,
      name: item.name,
      tool: item.tool,
      size: item.size,
      time: item.time,
      files,
    };
  });
  return JSON.stringify(serialized);
}

// Helper to deserialize history from local storage
function deserializeHistory(jsonStr: string): HistoryItem[] {
  try {
    const parsed = JSON.parse(jsonStr) as any[];
    if (!Array.isArray(parsed)) return [];
    
    return parsed.map((item) => {
      const files = item.files?.map((file: any) => {
        if (file.base64) {
          const binaryString = window.atob(file.base64);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          return {
            name: file.name,
            bytes: bytes,
          };
        }
        return {
          name: file.name,
          dataUrl: file.dataUrl,
        };
      });
      return {
        id: item.id,
        name: item.name,
        tool: item.tool,
        size: item.size,
        time: item.time,
        files,
      };
    });
  } catch (err) {
    console.error('Error deserializing history:', err);
    return [];
  }
}

function safeSaveHistory(key: string, items: HistoryItem[]) {
  const now = Date.now();
  const ONE_HOUR = 3600000;
  let activeItems = items.filter((item) => now - item.time < ONE_HOUR);

  try {
    const serialized = serializeHistory(activeItems);
    localStorage.setItem(key, serialized);
  } catch (err) {
    console.warn('Storage quota warning. Pruning larger payloads to fit...', err);
    let successfullySaved = false;
    for (let attempts = 1; attempts <= 3; attempts++) {
      try {
        activeItems = activeItems.map((item, idx) => {
          if (idx >= activeItems.length - attempts) {
            return {
              ...item,
              files: item.files?.map((f) => ({ name: f.name })),
            };
          }
          return item;
        });
        const serialized = serializeHistory(activeItems);
        localStorage.setItem(key, serialized);
        successfullySaved = true;
        break;
      } catch (innerErr) {
        // continue
      }
    }
    
    if (!successfullySaved) {
      try {
        const metaOnly = activeItems.map((item) => ({
          ...item,
          files: item.files?.map((f) => ({ name: f.name })),
        }));
        localStorage.setItem(key, serializeHistory(metaOnly));
      } catch (finalErr) {
        console.error('Failed to save even metadata only', finalErr);
      }
    }
  }
}

export default function App() {
  const [view, setView] = useState<string>('home');
  const [activeTool, setActiveTool] = useState<Tool | null>(null);
  const [collapsed, setCollapsed] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [theme, setTheme] = useState<string>('dark');
  const [user, setUser] = useState<User | null>(null);
  const [showAuth, setShowAuth] = useState<boolean>(false);
  const [showProfile, setShowProfile] = useState<boolean>(false);
  const [showTcModal, setShowTcModal] = useState<boolean>(false);
  const [tcWarningMode, setTcWarningMode] = useState<boolean>(false);
  const [pendingTool, setPendingTool] = useState<Tool | null>(null);
  const [showLoginRequired, setShowLoginRequired] = useState<boolean>(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null);

  // Trigger quick informational toast message
  const triggerToast = (msg: string, type: 'ok' | 'err' = 'ok') => {
    setToast({ msg, type });
  };

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(timer);
  }, [toast]);

  // Sync theme selection to document root element
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Sync auth state with Firebase Authentication
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser && fbUser.emailVerified) {
        const nextUser = {
          name: fbUser.displayName || fbUser.email?.split('@')[0] || 'User',
          email: fbUser.email || '',
        };
        setUser(nextUser);
        
        // Force reset active tools and view to protect previous guest/user state
        setView('home');
        setActiveTool(null);

        // Load specific user's history
        const key = `docify_history_${nextUser.email.toLowerCase()}`;
        const raw = localStorage.getItem(key);
        if (raw) {
          const loaded = deserializeHistory(raw);
          const now = Date.now();
          const ONE_HOUR = 3600000;
          setHistory(loaded.filter((h) => now - h.time < ONE_HOUR));
        } else {
          setHistory([]);
        }
      } else {
        setUser(null);
        
        // Force navigate back and clean up all results / tools on logout!
        setView('home');
        setActiveTool(null);
        
        // Load guest's history
        const key = 'docify_history_guest';
        const raw = localStorage.getItem(key);
        if (raw) {
          const loaded = deserializeHistory(raw);
          const now = Date.now();
          const ONE_HOUR = 3600000;
          setHistory(loaded.filter((h) => now - h.time < ONE_HOUR));
        } else {
          setHistory([]);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Check T&C acceptance when user successfully logs in
  useEffect(() => {
    if (user) {
      const accepted = localStorage.getItem(`docify_tc_accepted_${user.email.toLowerCase()}`) === 'true';
      if (!accepted) {
        setShowTcModal(true);
        setTcWarningMode(false);
      }
    }
  }, [user]);

  const handleTcAccept = () => {
    const key = user ? `docify_tc_accepted_${user.email.toLowerCase()}` : 'docify_tc_accepted_guest';
    localStorage.setItem(key, 'true');
    setShowTcModal(false);
    triggerToast('Terms & Conditions accepted. Thank you!', 'ok');
    if (pendingTool) {
      setActiveTool(pendingTool);
      setView('tool');
      setPendingTool(null);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleTcDecline = async () => {
    setShowTcModal(false);
    setPendingTool(null);
    if (user) {
      try {
        await signOut(auth);
        triggerToast('You must accept our Terms to utilize account features.', 'err');
      } catch (err) {
        console.error(err);
      }
    } else {
      triggerToast('You have declined the Terms & Conditions.', 'err');
    }
  };

  const addHistoryItem = (item: { name: string; tool: string; size: string; files?: HistoryFile[] }) => {
    const newItem: HistoryItem = {
      id: Math.random().toString(36).substring(2, 11),
      name: item.name,
      tool: item.tool,
      size: item.size,
      time: Date.now(),
      files: item.files,
    };

    setHistory((prev) => {
      const updated = [newItem, ...prev];
      const key = user ? `docify_history_${user.email.toLowerCase()}` : 'docify_history_guest';
      safeSaveHistory(key, updated);
      return updated;
    });
  };

  const handleSelectTool = (tool: Tool) => {
    // Prevent usage of tools if user is not authenticated, instead showing the beautiful login-required popup dialog
    if (!user) {
      setShowLoginRequired(true);
      return;
    }

    const key = `docify_tc_accepted_${user.email.toLowerCase()}`;
    const isAccepted = localStorage.getItem(key) === 'true';

    if (!isAccepted) {
      setPendingTool(tool);
      setTcWarningMode(true);
      setShowTcModal(true);
      return;
    }

    setActiveTool(tool);
    setView('tool');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGoHome = () => {
    setView('home');
    setActiveTool(null);
  };

  const getToolIcon = (id: string, color: string) => {
    const props = { size: 18, style: { color } };
    switch (id) {
      case 'compress':
        return <Minimize2 {...props} />;
      case 'merge':
        return <Combine {...props} />;
      case 'split':
        return <Scissors {...props} />;
      case 'remove':
        return <Trash2 {...props} />;
      case 'rotate':
        return <RotateCw {...props} />;
      case 'watermark':
        return <Stamp {...props} />;
      case 'pdf2img':
        return <ImageIcon {...props} />;
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden relative font-sans leading-normal">
      {/* Dynamic blurred glow backdrops */}
      <div className="fixed w-[500px] h-[500px] rounded-full filter blur-[120px] bg-[rgba(124,106,240,0.06)] -top-[160px] -left-[160px] pointer-events-none z-0" />
      <div className="fixed w-[360px] h-[360px] rounded-full filter blur-[100px] bg-[rgba(240,98,146,0.05)] bottom-0 right-[60px] pointer-events-none z-0" />

      {/* Styled toast notifications floating overlay */}
      {toast && (
        <div className={`toast shadow-lg transition-transform duration-200 animate-slide-in ${toast.type === 'err' ? 'err animate-bounce' : ''}`}>
          {toast.type === 'err' ? '⚠️' : '✨'} <span className="font-semibold">{toast.msg}</span>
        </div>
      )}

      {/* Account authentication wizard overlay */}
      {showAuth && (
        <AuthModal
          onClose={() => setShowAuth(false)}
          onLogin={(u) => setUser(u)}
          onToast={triggerToast}
        />
      )}

      {/* Profile settings manager overlay */}
      {showProfile && user && (
        <ProfileModal
          user={user}
          onClose={() => setShowProfile(false)}
          onUpdateUser={(updated) => setUser(updated)}
          onLogout={async () => {
            try {
              await signOut(auth);
              triggerToast('Signed out of profile session.');
            } catch (err: any) {
               triggerToast('Error signing out.', 'err');
            }
          }}
          onToast={triggerToast}
        />
      )}

      {/* Terms and Conditions / Privacy Policy Acceptance overlay */}
      {showTcModal && (
        <TcModal
          warningMode={tcWarningMode}
          onAccept={handleTcAccept}
          onDecline={handleTcDecline}
        />
      )}

      {/* Beautiful High-Fidelity Login Required custom popup overlay */}
      {showLoginRequired && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-md z-[200] flex items-center justify-center p-4 animate-fade-in select-none">
          <div className="bg-[var(--surface)] border border-[var(--border)] rounded-[24px] p-8 w-full max-w-[420px] shadow-2xl relative text-center">
            {/* Centered Large Branding Logo with Signature animation */}
            <div className="flex justify-center mb-6">
              <div className="bg-[#FFFFFF] p-3 rounded-2xl shadow-xl shadow-red-500/5 border border-red-500/10 hover:scale-105 transition-transform duration-300">
                <LogoIcon size={80} />
              </div>
            </div>

            <h2 className="font-display font-black text-2xl text-[var(--text)] tracking-tight mb-2">
              Sign In to Continue
            </h2>
            
            <p className="text-xs text-[var(--muted)] leading-relaxed mb-8 font-sans">
              To keep your data safe and utilize all local offline-safe tools, multi-pass precision compression calibrator, and instant document processors, please log in or sign up first. It is completely free!
            </p>

            {/* Action buttons */}
            <div className="flex flex-col gap-3">
              <button
                type="button"
                onClick={() => {
                  setShowLoginRequired(false);
                  setShowAuth(true);
                }}
                className="w-full bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-red-500/30 hover:shadow-red-500/40 active:scale-[0.98] transition-all cursor-pointer text-sm"
              >
                Sign In / Join Docify
              </button>
              
              <button
                type="button"
                onClick={() => setShowLoginRequired(false)}
                className="w-full bg-[var(--surface2)] hover:bg-[var(--border)] border border-[var(--border)] text-[var(--text)] font-semibold py-2.5 px-4 rounded-xl active:scale-[0.98] transition-all cursor-pointer text-xs"
              >
                Back to Dashboard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SIDEBAR NAVIGATION SHELL */}
      <Sidebar
        view={view}
        onSetView={(v) => {
          setView(v);
          setActiveTool(null);
        }}
        activeTool={activeTool}
        onSelectTool={handleSelectTool}
        collapsed={collapsed}
        onToggleCollapse={() => setCollapsed(!collapsed)}
        tools={TOOLS}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      {/* CORE CONTAINER SEGMENT */}
      <div className="flex-1 flex flex-col overflow-hidden relative z-10 w-full">
        
        {/* UPPER NAVIGATION BAR */}
        <Header
          view={view}
          onGoHome={handleGoHome}
          activeTool={activeTool}
          theme={theme}
          onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
          user={user}
          onSignOut={async () => {
            try {
              await signOut(auth);
              triggerToast('Signed out of profile session.');
            } catch (err: any) {
              triggerToast('Error signing out.', 'err');
            }
          }}
          onShowAuth={() => setShowAuth(true)}
          onShowProfile={() => setShowProfile(true)}
          onOpenMobileMenu={() => setMobileMenuOpen(true)}
        />

        {/* LOWER RESPONSIVE WORKSPACE WRAPPER */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 custom-scroll flex flex-col justify-between">
          <div className="w-full max-w-[1060px] mx-auto mb-10 flex-1">
            
            {/* VIEW WRAPPERS WITH CONDITIONAL RENDERS */}
            {view === 'home' && (
              <div className="animate-fade-in">
                {/* Brand Showcase Hero */}
                <div className="mb-10 mt-2">
                  <h1 className="text-4xl md:text-5xl font-display font-black text-[var(--text)] tracking-tight leading-[1.1] mb-3 select-none">
                    Your local PDF suite.
                    <br />
                    <span className="bg-gradient-to-r from-[var(--accent)] to-[var(--accent2)] bg-clip-text text-transparent">
                      Zero server uploads. Total privacy.
                    </span>
                  </h1>
                  <p className="text-sm md:text-base text-[var(--muted)] max-w-lg mt-3 leading-relaxed">
                    Powered by high performance WebAssembly compiling your operations directly on your device. Never compromise security.
                  </p>
                </div>

                {/* Dashboard Tools Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {TOOLS.map((t) => (
                    <div
                      key={t.id}
                      className="tool-card hover:translate-y-[-4px] active:scale-[0.99] flex flex-col justify-between"
                      onClick={() => handleSelectTool(t)}
                    >
                      <div>
                        <div
                          style={{
                            background: `${t.color}15`,
                            borderColor: `${t.color}35`,
                          }}
                          className="w-11 h-11 rounded-xl flex items-center justify-center border mb-4"
                        >
                          {getToolIcon(t.id, t.color)}
                        </div>
                        <h3 className="font-display font-bold text-base text-[var(--text)] mb-1.5 shrink-0">
                          {t.name}
                        </h3>
                        <p className="text-xs text-[var(--muted)] leading-relaxed font-sans mt-1">
                          {t.desc}
                        </p>
                      </div>
                      <div className="mt-5 flex items-center gap-1.5 text-xs font-bold leading-none select-none transition-transform" style={{ color: t.color }}>
                        <span>Open module</span> <ArrowRight size={12} className="opacity-80 transition-transform hover:translate-x-1" />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Security Reassurance Banner */}
                <div className="mt-12 bg-[var(--surface)] border border-[var(--border)] rounded-2xl p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    ['🔒', '100% Offline-Safe', 'Processing takes place in sandboxed local javascript threads.'],
                    ['⚡', 'Instantly Compiled', 'No heavy upload transfers or network latency lags.'],
                    ['🆓', 'Zero Paywalls', 'Absolutely free without visual advertisement clutters.'],
                    ['📱', 'Fluid Responsive', 'Optimized to scale correctly across any device layout.'],
                  ].map(([emoji, caption, detail]) => (
                    <div key={caption} className="flex flex-col gap-1.5 select-none animate-fade-in">
                      <span className="text-2xl mb-1">{emoji}</span>
                      <h4 className="font-display font-bold text-sm text-[var(--text)]">{caption}</h4>
                      <p className="text-[11px] text-[var(--muted)] leading-relaxed font-sans">{detail}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* INTEGRATED GRAPHICAL TOOLSETS */}
            {view === 'tool' && activeTool && (
              <div className="animate-fade-in flex-1">
                {(() => {
                  switch (activeTool.id) {
                    case 'compress':
                      return <CompressTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    case 'merge':
                      return <MergeTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    case 'split':
                      return <SplitTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    case 'remove':
                      return <RemoveTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    case 'rotate':
                      return <RotateTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    case 'watermark':
                      return <WatermarkTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    case 'pdf2img':
                      return <Pdf2ImgTool onAddHistory={addHistoryItem} onToast={triggerToast} />;
                    default:
                      return null;
                  }
                })()}
              </div>
            )}

            {/* CORRESPONDING GENERIC PAGES */}
            {view === 'contact' && <ContactPage onToast={triggerToast} />}
            {view === 'privacy' && <PrivacyPage />}
            {view === 'terms' && <TermsPage />}
            {view === 'history' && (
              <HistoryPage
                history={history}
                onClearHistory={() => {
                  setHistory([]);
                  triggerToast('Session download history cleared.');
                }}
              />
            )}

          </div>

          {/* PAGE UTILITY ACCREDITATIONS FOOTER (humble, literal human label) */}
          <footer className="pt-6 border-t border-[var(--border)] flex flex-col sm:flex-row justify-between items-center gap-4 w-full max-w-[1060px] mx-auto shrink-0 select-none">
            <div className="flex items-center gap-3 flex-wrap justify-center sm:justify-start">
              <Logo size={22} textSizeClass="text-[14px]" />
              <span className="text-[11px] text-[var(--muted)] font-medium">
                © 2026 All rights reserved
              </span>
            </div>
            
            <div className="flex flex-wrap gap-x-5 gap-y-2 justify-center text-xs font-semibold text-[var(--muted)]">
              <button
                type="button"
                onClick={() => {
                  setView('contact');
                  setActiveTool(null);
                }}
                className="hover:text-[var(--text)] border-none bg-transparent cursor-pointer transition-colors"
              >
                Contact Us
              </button>
              <button
                type="button"
                onClick={() => {
                  setView('privacy');
                  setActiveTool(null);
                }}
                className="hover:text-[var(--text)] border-none bg-transparent cursor-pointer transition-colors"
              >
                Privacy Policy
              </button>
              <button
                type="button"
                onClick={() => {
                  setView('terms');
                  setActiveTool(null);
                }}
                className="hover:text-[var(--text)] border-none bg-transparent cursor-pointer transition-colors"
              >
                Terms & Conditions
              </button>
            </div>
          </footer>

        </main>
      </div>
    </div>
  );
}
