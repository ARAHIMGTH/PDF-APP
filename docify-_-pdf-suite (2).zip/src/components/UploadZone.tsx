/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useRef, DragEvent, ChangeEvent } from 'react';
import { Upload } from 'lucide-react';

interface UploadZoneProps {
  onFiles: (files: File[]) => void;
  multiple?: boolean;
}

export default function UploadZone({ onFiles, multiple = true }: UploadZoneProps) {
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const pdfs = Array.from(files).filter(
      (file) => file.type === 'application/pdf' || file.name.endsWith('.pdf')
    );
    if (!pdfs.length) {
      alert('Please upload PDF files only.');
      return;
    }
    onFiles(pdfs);
  };

  const handleDrag = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div
      className={`upload-zone ${dragActive ? 'drag-active' : ''}`}
      onClick={onButtonClick}
      onDragEnter={handleDrag}
      onDragOver={handleDrag}
      onDragLeave={handleDrag}
      onDrop={handleDrop}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf"
        multiple={multiple}
        className="hidden"
        onChange={handleChange}
      />
      <div className="w-14 h-14 rounded-2xl bg-[rgba(124,106,240,0.12)] border border-[rgba(124,106,240,0.25)] flex items-center justify-center text-[var(--accent)]">
        <Upload size={24} />
      </div>
      <p className="font-display font-bold text-lg text-[var(--text)]">
        Drop your PDF{multiple ? 's' : ''} here
      </p>
      <p className="text-xs text-[var(--muted)]">
        or click to browse · PDF files only
      </p>
    </div>
  );
}
